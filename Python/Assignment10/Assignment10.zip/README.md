scrapper.py is  the file intended to serve the purpose of assignment for Tutedude Price Tracer.

### Changes:
- As Amazon is not supporting automated access, flipkart is being used here
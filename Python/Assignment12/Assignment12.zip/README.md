sel\_5.py is the working project file submitted as assignment

